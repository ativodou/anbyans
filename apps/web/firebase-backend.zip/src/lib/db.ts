import {
  collection, doc, addDoc, setDoc, getDoc, getDocs, updateDoc, deleteDoc,
  query, where, orderBy, limit, serverTimestamp,
  Timestamp, QueryConstraint,
} from 'firebase/firestore';
import { db } from './firebase';

/* ── Types ──────────────────────────────────────────────────── */

export interface EventSection {
  id: string;
  name: string;
  color: string;
  capacity: number;
  price: number;
  sold: number;
  description?: string;
}

export interface EventDoc {
  id?: string;
  organizerId: string;
  title: string;
  description: string;
  category: string;
  venue: {
    name: string;
    address: string;
    city: string;
    country: string;
    lat?: number;
    lng?: number;
  };
  date: Timestamp;
  endDate?: Timestamp;
  doorsOpen?: string;
  startTime?: string;
  artists?: string[];
  coverImage?: string;
  images?: string[];
  sections: EventSection[];
  restrictions?: Record<string, unknown>;
  status: 'draft' | 'pending' | 'approved' | 'live' | 'completed' | 'cancelled';
  stats: {
    totalCapacity: number;
    totalSold: number;
    totalRevenue: number;
  };
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface TicketDoc {
  id?: string;
  eventId: string;
  userId: string;
  sectionId: string;
  seatLabel: string;
  price: number;
  fees: number;
  total: number;
  status: 'active' | 'used' | 'transferred' | 'refunded' | 'expired';
  usedAt?: Timestamp;
  scannedBy?: string;
  qrSecret: string;
  paymentMethod?: string;
  orderId?: string;
  createdAt?: Timestamp;
}

export interface OrderDoc {
  id?: string;
  userId: string;
  eventId: string;
  tickets: string[];
  ticketCount: number;
  subtotal: number;
  fees: number;
  total: number;
  paymentMethod: string;
  paymentStatus: 'pending' | 'completed' | 'failed' | 'refunded';
  paymentRef?: string;
  createdAt?: Timestamp;
}

export interface VendorDoc {
  id?: string;
  userId: string;
  organizerId: string;
  shopName: string;
  contactName: string;
  phone: string;
  city: string;
  inviteCode: string;
  status: 'active' | 'suspended' | 'settled';
  inventory: VendorInventory[];
  totalPurchased: number;
  totalSold: number;
  totalPaid: number;
  createdAt?: Timestamp;
}

export interface VendorInventory {
  eventId: string;
  sectionId: string;
  qty: number;
  costEach: number;
  sold: number;
  purchaseDate: Timestamp;
}

/* ── EVENTS ─────────────────────────────────────────────────── */

export async function createEvent(data: Omit<EventDoc, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
  const ref = await addDoc(collection(db, 'events'), {
    ...data,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  return ref.id;
}

export async function getEvent(id: string): Promise<EventDoc | null> {
  const snap = await getDoc(doc(db, 'events', id));
  return snap.exists() ? { id: snap.id, ...snap.data() } as EventDoc : null;
}

export async function getEvents(...constraints: QueryConstraint[]): Promise<EventDoc[]> {
  const q = query(collection(db, 'events'), ...constraints);
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as EventDoc);
}

export async function getPublicEvents(max = 20): Promise<EventDoc[]> {
  return getEvents(
    where('status', 'in', ['approved', 'live']),
    orderBy('date', 'asc'),
    limit(max)
  );
}

export async function getOrganizerEvents(organizerId: string): Promise<EventDoc[]> {
  return getEvents(
    where('organizerId', '==', organizerId),
    orderBy('createdAt', 'desc')
  );
}

export async function updateEvent(id: string, data: Partial<EventDoc>): Promise<void> {
  await updateDoc(doc(db, 'events', id), {
    ...data,
    updatedAt: serverTimestamp(),
  });
}

/* ── TICKETS ────────────────────────────────────────────────── */

export async function createTicket(data: Omit<TicketDoc, 'id' | 'createdAt'>): Promise<string> {
  const ref = await addDoc(collection(db, 'tickets'), {
    ...data,
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function getTicket(id: string): Promise<TicketDoc | null> {
  const snap = await getDoc(doc(db, 'tickets', id));
  return snap.exists() ? { id: snap.id, ...snap.data() } as TicketDoc : null;
}

export async function getUserTickets(userId: string): Promise<TicketDoc[]> {
  const q = query(
    collection(db, 'tickets'),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc')
  );
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as TicketDoc);
}

export async function markTicketUsed(ticketId: string, scannedBy: string): Promise<void> {
  await updateDoc(doc(db, 'tickets', ticketId), {
    status: 'used',
    usedAt: serverTimestamp(),
    scannedBy,
  });
}

/* ── ORDERS ─────────────────────────────────────────────────── */

export async function createOrder(data: Omit<OrderDoc, 'id' | 'createdAt'>): Promise<string> {
  const ref = await addDoc(collection(db, 'orders'), {
    ...data,
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function getUserOrders(userId: string): Promise<OrderDoc[]> {
  const q = query(
    collection(db, 'orders'),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc')
  );
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as OrderDoc);
}

/* ── VENDORS ────────────────────────────────────────────────── */

export async function createVendor(data: Omit<VendorDoc, 'id' | 'createdAt'>): Promise<string> {
  const ref = await addDoc(collection(db, 'vendors'), {
    ...data,
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function getOrganizerVendors(organizerId: string): Promise<VendorDoc[]> {
  const q = query(
    collection(db, 'vendors'),
    where('organizerId', '==', organizerId)
  );
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }) as VendorDoc);
}

export async function getVendorByInviteCode(code: string): Promise<VendorDoc | null> {
  const q = query(collection(db, 'vendors'), where('inviteCode', '==', code), limit(1));
  const snap = await getDocs(q);
  return snap.empty ? null : { id: snap.docs[0].id, ...snap.docs[0].data() } as VendorDoc;
}

/* ── UTILITY ────────────────────────────────────────────────── */

export function generateInviteCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 8; i++) {
    if (i === 4) code += '-';
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export function generateQRSecret(): string {
  return crypto.randomUUID().replace(/-/g, '').slice(0, 24);
}
