import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase';

export type UserRole = 'fan' | 'organizer' | 'vendor' | 'admin';

export interface AnbyansUser {
  uid: string;
  role: UserRole;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  city: string;
  country: string;
  // Organizer fields
  businessName?: string;
  businessType?: string;
  payoutMethod?: string;
  payoutAccount?: string;
  // Vendor fields
  shopName?: string;
  inviteCode?: string;
  organizerId?: string;
}

/* ── Sign Up ────────────────────────────────────────────────── */

interface SignUpData {
  email: string;
  password: string;
  role: UserRole;
  firstName: string;
  lastName: string;
  phone: string;
  city: string;
  country: string;
  // Optional role-specific
  businessName?: string;
  businessType?: string;
  payoutMethod?: string;
  payoutAccount?: string;
  shopName?: string;
  inviteCode?: string;
  organizerId?: string;
}

export async function signUp(data: SignUpData): Promise<AnbyansUser> {
  const { email, password, ...profile } = data;

  // Create Firebase Auth user
  const cred = await createUserWithEmailAndPassword(auth, email, password);

  // Build user document
  const userDoc: Record<string, unknown> = {
    uid: cred.user.uid,
    email,
    ...profile,
    verified: false,
    status: profile.role === 'organizer' ? 'pending' : 'active',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  // Save to Firestore
  await setDoc(doc(db, 'users', cred.user.uid), userDoc);

  return { uid: cred.user.uid, email, ...profile };
}

/* ── Sign In ────────────────────────────────────────────────── */

export async function signIn(email: string, password: string): Promise<AnbyansUser> {
  const cred = await signInWithEmailAndPassword(auth, email, password);
  const snap = await getDoc(doc(db, 'users', cred.user.uid));

  if (!snap.exists()) {
    throw new Error('User profile not found');
  }

  return snap.data() as AnbyansUser;
}

/* ── Sign Out ───────────────────────────────────────────────── */

export async function signOut(): Promise<void> {
  await firebaseSignOut(auth);
}

/* ── Get Current User Profile ───────────────────────────────── */

export async function getUserProfile(uid: string): Promise<AnbyansUser | null> {
  const snap = await getDoc(doc(db, 'users', uid));
  return snap.exists() ? (snap.data() as AnbyansUser) : null;
}

/* ── Auth State Listener ────────────────────────────────────── */

export function onAuthChange(callback: (user: FirebaseUser | null) => void) {
  return onAuthStateChanged(auth, callback);
}
